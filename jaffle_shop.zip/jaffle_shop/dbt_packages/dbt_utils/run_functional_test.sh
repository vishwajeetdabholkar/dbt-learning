#!/bin/bash

python3 -m pytest tests/functional --profile $1
