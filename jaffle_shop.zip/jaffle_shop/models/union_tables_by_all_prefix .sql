{{ union_tables_by_prefix(

      database='bqdemo-338306',
      schema='jaffle_shop', 
      prefix='all__'
        
      )
      
  }}